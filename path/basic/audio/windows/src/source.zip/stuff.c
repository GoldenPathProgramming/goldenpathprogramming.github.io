#include <stdint.h>
#include <assert.h>
#include <stdio.h>
#include <conio.h>

static bool restart_audio = true;
static bool quit = false;
int32_t sampling_rate = 48000;

#define LOG(...) do { printf(__VA_ARGS__); puts(""); } while (0)

const char *HResultToStr (HRESULT result) {
    static char wasapi_error_buffer[512];
    DWORD len;  // Number of chars returned.
    len = FormatMessageA(FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS, NULL, result, 0, wasapi_error_buffer, 512, NULL);
    if (len == 0) {
        HINSTANCE hInst = LoadLibraryA("Ntdsbmsg.dll");
        if (hInst == NULL)
            snprintf (wasapi_error_buffer, sizeof (wasapi_error_buffer), "Cannot convert error to string: Failed to load Ntdsbmsg.dll");
        else {
            len = FormatMessageA(FORMAT_MESSAGE_FROM_HMODULE | FORMAT_MESSAGE_IGNORE_INSERTS, hInst, result, 0, wasapi_error_buffer, 512, NULL);
            if (len == 0) snprintf (wasapi_error_buffer, sizeof (wasapi_error_buffer), "HRESULT error message not found");
            FreeLibrary( hInst );
        }
    }
    return wasapi_error_buffer;
}

static int frequency = 440;
static int wavelength = 48000 / 440;
static void CalculateWavelength () {
    if (frequency < 40) frequency = 40;
    if (frequency > 10000) frequency = 10000;
    wavelength = sampling_rate / frequency;
	LOG ("Wavelength: %dHz", frequency);
}

void SoundLoop_int (WAVEFORMATEXTENSIBLE wave_format, HANDLE event_handle, IAudioRenderClient *render, UINT32 frames_per_period);
void SoundLoop_float (WAVEFORMATEXTENSIBLE wave_format, HANDLE event_handle, IAudioRenderClient *render, UINT32 frames_per_period);

#define DO_OR_QUIT(function_call__, error_message__) do { auto result = function_call__; assert (result == S_OK); if (result != S_OK) { LOG (error_message__ " [%ld] [%s]", result, HResultToStr(result)); return -1; } } while (0)
#define DO_OR_CONTINUE(function_call__, error_message__) do { auto result = function_call__; if (result != S_OK) { LOG (error_message__ " [%ld] [%s]", result, HResultToStr(result)); } } while (0)
#define QUIT_IF_NULL(variable__, error_message__) do { auto __var__ = (variable__); assert (__var__); if (__var__ == NULL) { LOG (error_message__); return -1; } } while (0)
#define IF_NULL_RESTART(variable__, message__) if (variable__ == NULL) { LOG (message__); restart_audio = true; continue; }
#define BREAK_ON_FAIL(code__, message__) { auto result = code__; assert (!FAILED(result)); if (FAILED(result)) { LOG (message__); break; } }
#define DO_OR_RESTART(function_call__, error_message__) ({ auto result = function_call__; if (result != S_OK) { LOG (error_message__ " [%ld] [%s]", result, HResultToStr(result)); restart_audio = true; continue; } })

#define VAR_DEFER_UNIQUE_NAME__(counter__) unique_##counter__
#define VAR_DEFER_UNIQUE_NAME_(counter__) VAR_DEFER_UNIQUE_NAME__(counter__)
#define VAR_DEFER_UNIQUE_NAME VAR_DEFER_UNIQUE_NAME_(__COUNTER__)
#define VAR_DEFER_(type__, name__, function_body__, unique_name__) \
    void unique_name__ (type__ *this) function_body__ \
    type__ name__ __attribute__((cleanup(unique_name__)))
#define VAR_DEFER(type__, name__, function_body__) VAR_DEFER_(type__, name__, function_body__, VAR_DEFER_UNIQUE_NAME)
#define DEFER(function_body__) VAR_DEFER (char, VAR_DEFER_UNIQUE_NAME, { function_body__ ;})